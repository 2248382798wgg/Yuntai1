<template>
	<view>
		<view style="background-color: #F8F8F8;width: 100%;height: 200px;">
			<view style="text-align:center;">
				<view style="padding-top: 20%;font-size: 20px;color: #B4B6BA;">
					添加封面
				</view>
			</view>
		</view>
		
		
		<view style="display: flex;width: 100%;justify-content: center;">
			<view style="border: #C8C7CC 1px solid;width: 90%;">
				
			</view>
		</view>
		
		<view style="margin: 5%;">
			<input type="text" placeholder='请输入正文'/>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {

			}
		},
		methods: {

		}
	}
</script>

<style>

</style>
