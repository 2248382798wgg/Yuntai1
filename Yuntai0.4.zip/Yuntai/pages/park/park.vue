<template>
	<view>
		<view>
			<image style="width: 100%;height: 700px;" src="../../static/ZM_3C880TN_%5BSC85V5DUZKG.png"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
