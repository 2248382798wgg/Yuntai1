<template>
	<view>
		<view>
			<image style="width: 100%;height: 700px;" src="../../static/C%7DOW~%5BO_ZK%5DU)IIFD%7B1SCJ6.png"></image>
		</view>
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		}
	}
</script>

<style>

</style>
