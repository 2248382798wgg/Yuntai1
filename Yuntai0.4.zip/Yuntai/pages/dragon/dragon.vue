<template>
	<view>
		
	</view>
</template>

<script>
	import json from '../../testdata/index.json'; //引入js文件
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		onLoad(res) {
			this.img = res.img
			
		}
	}
</script>

<style>

</style>
