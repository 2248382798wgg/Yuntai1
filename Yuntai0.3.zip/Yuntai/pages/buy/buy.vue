<template>
	<view>
		
	</view>
</template>

<script>
	export default {
		data() {
			return {
				
			}
		},
		methods: {
			
		},
		onLoad(options) {
			var ner = JSON.parse(decodeURIComponent(options.data));
			console.log(ner)
		}
	}
</script>

<style>

</style>
